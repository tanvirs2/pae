<?php

namespace App;

use App\Traits\Functions;
use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    use Functions;
}
