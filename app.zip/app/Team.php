<?php

namespace App;

use App\Traits\Functions;
use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    use Functions;
}
