<?php

namespace App;

use App\Traits\Functions;
use Illuminate\Database\Eloquent\Model;

class Others extends Model
{
    use Functions;
}
