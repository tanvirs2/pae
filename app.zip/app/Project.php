<?php

namespace App;

use App\Traits\Functions;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use Functions;
}
