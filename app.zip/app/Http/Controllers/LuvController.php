<?php

namespace App\Http\Controllers;

use App\Luv;
use Illuminate\Http\Request;

class LuvController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Luv  $luv
     * @return \Illuminate\Http\Response
     */
    public function show(Luv $luv)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Luv  $luv
     * @return \Illuminate\Http\Response
     */
    public function edit(Luv $luv)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Luv  $luv
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Luv $luv)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Luv  $luv
     * @return \Illuminate\Http\Response
     */
    public function destroy(Luv $luv)
    {
        //
    }
}
