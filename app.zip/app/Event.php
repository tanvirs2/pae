<?php

namespace App;

use App\Traits\Functions;
use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    use Functions;
}
