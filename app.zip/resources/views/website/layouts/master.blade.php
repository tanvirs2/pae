@include('website.layouts.header')
@include('website.layouts.nav')

@yield('website-content')


@include('website.layouts.footer')