@include('admin.layouts.header')
@include('admin.layouts.nav')


@yield('admin-content')


@include('admin.layouts.footer')