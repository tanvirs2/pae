<?php

return [
    'home_page' => 'বাংলা'
];
