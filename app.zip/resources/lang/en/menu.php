<?php

return [
    'home_page' => 'Home'
];
